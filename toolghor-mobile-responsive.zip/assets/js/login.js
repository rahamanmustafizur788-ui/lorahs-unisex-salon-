(()=>{
window.__tgLogin=1;
const C=window.TG_CONFIG||{},$=id=>document.getElementById(id);
const nav=u=>window.TG_NAV?window.TG_NAV(u):location.replace(u);
const store=()=>{try{return localStorage.getItem('tg_rm')==='0'?sessionStorage:localStorage}catch(e){return localStorage}};
const unsafe=k=>{if(/^sb_secret_/.test(k))return true;try{return JSON.parse(atob(k.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role==='service_role'}catch(e){return false}};
let sb,mode='login';
const mk=()=>(sb=supabase.createClient(C.url,C.key,{auth:{storage:store(),persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,flowType:'pkce'}}));
const E=m=>{m=(m||'').toLowerCase();return m.includes('expired')?'This link has expired. Please request a new one.':m.includes('invalid login')?'Incorrect email or password.':m.includes('not confirmed')?'Please verify your email first. Check your inbox and spam folder.':m.includes('already registered')?'An account with this email already exists. Try signing in.':m.includes('rate limit')||m.includes('too many')?'Too many attempts. Please wait a few minutes and try again.':m.includes('password')?'Password problem: use at least 8 characters with a letter and a number (and different from your old one).':m.includes('fetch')||m.includes('network')?'Network error. Check your connection and try again.':'Something went wrong. Please try again.'};
const note=(t,k)=>{const n=$('notice');n.textContent=t||'';n.className='notice '+(k||'err');n.style.display=t?'block':'none'};
const EM=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const q=new URLSearchParams(location.search),nx=q.get('next'),dest=nx&&/^\/(?!\/)[\w\-\/.]*$/.test(nx)?nx:'/dashboard.html';
const setMode=m=>{mode=m;const L=m==='login',R=m==='register',G=m==='forgot';
 $('loginTab').classList.toggle('active',L);$('registerTab').classList.toggle('active',R);
 $('nameField').classList.toggle('hidden',!R);$('confirmField').classList.toggle('hidden',!R);$('passField').classList.toggle('hidden',G);$('loginOptions').classList.toggle('hidden',!L);
 $('orRow').classList.toggle('hidden',G);$('googleBtn').classList.toggle('hidden',G);$('backRow').classList.toggle('hidden',!G);$('authForm').style.display='';
 $('heading').textContent=L?'Welcome back':R?'Create your account':'Reset your password';
 $('sub').textContent=L?'Sign in to your ToolGhor account.':R?'Join ToolGhor to save your favourite tools.':'Enter your email and we will send you a reset link.';
 $('submitBtn').textContent=L?'Sign In':R?'Create Account':'Send reset link';$('password').autocomplete=L?'current-password':'new-password';note('')};
$('loginTab').onclick=()=>setMode('login');$('registerTab').onclick=()=>setMode('register');$('forgot').onclick=e=>{e.preventDefault();setMode('forgot')};$('back').onclick=e=>{e.preventDefault();setMode('login')};
$('togglePass').onclick=()=>{const p=$('password');p.type=p.type==='password'?'text':'password';$('togglePass').textContent=p.type==='password'?'Show':'Hide'};
setMode(q.get('mode')==='register'||location.hash==='#register'?'register':q.get('mode')==='forgot'?'forgot':'login');
const lock=m=>{note(m);document.querySelectorAll('#submitBtn,#googleBtn').forEach(b=>b.disabled=true)};
if(C.key&&unsafe(C.key))return lock('Security error: a secret/service_role key was found in config.js. Remove it now, use only the publishable key, and rotate the exposed key in Supabase.');
if(!window.supabase||!C.url||!C.key)return lock('Sign-in is not set up yet. The site owner must add the Supabase URL and publishable key in assets/js/config.js.');
mk();
const resend=em=>{const b=document.createElement('button');b.type='button';b.className='rs';b.textContent='Resend verification email';b.onclick=async()=>{const{error}=await sb.auth.resend({type:'signup',email:em,options:{emailRedirectTo:location.origin+'/login.html?verified=1'}});note(error?E(error.message):'Verification email sent. Check your inbox.',error?'err':'ok')};$('notice').append(document.createElement('br'),b)};
const act=async(em,pw,nm)=>{
 if(mode==='login'){const r=$('remember').checked,was=store()===localStorage;try{localStorage.setItem('tg_rm',r?'1':'0')}catch(e){}if(was!==r){sb.auth.stopAutoRefresh();mk()}const{error}=await sb.auth.signInWithPassword({email:em,password:pw});if(error){note(E(error.message));if(/not confirmed/i.test(error.message))resend(em);return}return nav(dest)}
 if(mode==='register'){const{data,error}=await sb.auth.signUp({email:em,password:pw,options:{data:{full_name:nm},emailRedirectTo:location.origin+'/login.html?verified=1'}});if(error)return note(E(error.message));if(data.session)return nav('/dashboard.html');$('authForm').style.display='none';return note('Almost done! If this email can be registered, we have sent a verification link to it. Open it to activate your account, then sign in.','ok')}
 const{error}=await sb.auth.resetPasswordForEmail(em,{redirectTo:location.origin+'/reset-password.html'});if(error&&!/not found/i.test(error.message))return note(E(error.message));$('authForm').style.display='none';note('If an account exists for that email, a password reset link is on its way.','ok')};
$('authForm').onsubmit=async e=>{e.preventDefault();note('');document.querySelectorAll('#authForm input').forEach(i=>i.removeAttribute('aria-invalid'));
 const bad=(id,m)=>{note(m);$(id).setAttribute('aria-invalid','true');$(id).focus()},em=$('email').value.trim(),pw=$('password').value,nm=$('name').value.trim();
 if(!EM.test(em))return bad('email','Enter a valid email address.');
 if(mode==='register'){if(nm.length<2||nm.length>60)return bad('name','Enter your full name (2–60 characters).');if(!(pw.length>=8&&/[A-Za-z]/.test(pw)&&/\d/.test(pw)))return bad('password','Use at least 8 characters, including a letter and a number.');if($('confirm').value!==pw)return bad('confirm','Passwords do not match.')}
 else if(mode==='login'&&!pw)return bad('password','Enter your password.');
 const b=$('submitBtn'),t=b.textContent;b.disabled=true;b.textContent='Please wait…';try{await act(em,pw,nm)}catch(x){note(E(x.message))}b.disabled=false;b.textContent=t};
$('googleBtn').onclick=async()=>{const{error}=await sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+'/dashboard.html'}});if(error)note(E(error.message))};
const le=new URLSearchParams(location.search+'&'+location.hash.slice(1));
if(le.get('error_description')||le.get('error'))note('This link is invalid or has expired. Please request a new one.');else if(q.get('verified')==='1')note('Email verified! You can now sign in.','ok');
sb.auth.getSession().then(({data:{session}})=>{if(session)nav(dest)}).catch(()=>{});
})();
