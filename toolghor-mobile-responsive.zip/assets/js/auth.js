(()=>{
const C=window.TG_CONFIG||{},T=window.TG_TOOLS||{},$=s=>document.querySelector(s),P=document.body.dataset.page||'tool';
const esc=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
const store=()=>{try{return localStorage.getItem('tg_rm')==='0'?sessionStorage:localStorage}catch(e){return localStorage}};
const nav=u=>window.TG_NAV?window.TG_NAV(u):location.replace(u);
const hadLink=/[?&#](code=|type=recovery|access_token=)/.test(location.search+location.hash);
const unsafe=k=>{if(/^sb_secret_/.test(k))return true;try{return JSON.parse(atob(k.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role==='service_role'}catch(e){return false}};
let sb;const mk=()=>(sb=supabase.createClient(C.url,C.key,{auth:{storage:store(),persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,flowType:'pkce'}}));
const E=m=>{m=(m||'').toLowerCase();return m.includes('expired')?'This link has expired. Please request a new one.':m.includes('invalid login')?'Incorrect email or password.':m.includes('not confirmed')?'Please verify your email first. Check your inbox and spam folder.':m.includes('already registered')?'An account with this email already exists. Try signing in.':m.includes('rate limit')||m.includes('too many')?'Too many attempts. Please wait a few minutes and try again.':m.includes('password')?'Password problem: use at least 8 characters with a letter and a number (and different from your old one).':m.includes('fetch')||m.includes('network')?'Network error. Check your connection and try again.':'Something went wrong. Please try again.'};
const msg=(t,k)=>{const m=$('#msg');if(m){m.className='msg '+(k||'err');m.textContent=t}};
const R={email:v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim())||'Enter a valid email address.',name:v=>(v.trim().length>=2&&v.trim().length<=60)||'Enter your full name (2–60 characters).',password:v=>(v.length>=8&&/[A-Za-z]/.test(v)&&/\d/.test(v))||'Use at least 8 characters, including a letter and a number.',filled:v=>!!v||'Enter your password.',match:v=>v===$('#password').value||'Passwords do not match.'};
const bind=(checks,act)=>$('#f').addEventListener('submit',async e=>{e.preventDefault();msg('');let bad;
 for(const[id,fn]of checks){const el=$('#'+id),r=fn(el.value),er=$('#'+id+'-e');if(r!==true){er.textContent=r;el.setAttribute('aria-invalid','true');bad=bad||el}else{er.textContent='';el.removeAttribute('aria-invalid')}}
 if(bad){bad.focus();return}const b=$('#go'),t=b.textContent;b.disabled=true;b.textContent='Please wait…';try{await act()}catch(x){msg(E(x.message))}b.disabled=false;b.textContent=t});
document.addEventListener('click',e=>{const b=e.target.closest('.eye');if(!b)return;const i=$('#'+b.dataset.t),s=i.type=='password';i.type=s?'text':'password';b.setAttribute('aria-pressed',s);b.setAttribute('aria-label',s?'Hide password':'Show password')});
const linkErr=()=>{const q=new URLSearchParams(location.search+'&'+location.hash.slice(1));return q.get('error_description')||q.get('error')?'This link is invalid or has expired. Please request a new one.':''};
const nx=new URLSearchParams(location.search).get('next'),dest=nx&&/^\/(?!\/)[\w\-\/.]*$/.test(nx)?nx:'/dashboard.html';
const verifyUrl=()=>location.origin+'/login.html?verified=1';
const google=()=>{const g=$('#google');if(g)g.onclick=async()=>{const{error}=await sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+'/dashboard.html'}});if(error)msg(E(error.message))}};
const resend=em=>{const b=document.createElement('button');b.type='button';b.className='btn';b.textContent='Resend verification email';b.onclick=async()=>{const{error}=await sb.auth.resend({type:'signup',email:em,options:{emailRedirectTo:verifyUrl()}});msg(error?E(error.message):'Verification email sent. Check your inbox.',error?'err':'ok')};$('#msg').append(document.createElement('br'),b)};
const pages={
 async login(){const{data:{session}}=await sb.auth.getSession();if(session)return nav(dest);
  if(location.search.includes('verified=1'))msg('Email verified! You can now sign in.','ok');if(linkErr())msg(linkErr());google();
  bind([['email',R.email],['password',R.filled]],async()=>{const r=$('#remember').checked;try{localStorage.setItem('tg_rm',r?'1':'0')}catch(e){}sb.auth.stopAutoRefresh();mk();
   const em=$('#email').value.trim(),{error}=await sb.auth.signInWithPassword({email:em,password:$('#password').value});
   if(error){msg(E(error.message));if(error.message.toLowerCase().includes('not confirmed'))resend(em);return}nav(dest)})},
 async register(){const{data:{session}}=await sb.auth.getSession();if(session)return nav('/dashboard.html');google();
  bind([['name',R.name],['email',R.email],['password',R.password],['confirm',R.match]],async()=>{const em=$('#email').value.trim(),{data,error}=await sb.auth.signUp({email:em,password:$('#password').value,options:{data:{full_name:$('#name').value.trim()},emailRedirectTo:verifyUrl()}});
   if(error)return msg(E(error.message));if(data.session)return nav('/dashboard.html');$('#f').hidden=true;msg('Almost done! If this email can be registered, we have sent a verification link to it. Open it to activate your account, then sign in.','ok')})},
 forgot(){bind([['email',R.email]],async()=>{const{error}=await sb.auth.resetPasswordForEmail($('#email').value.trim(),{redirectTo:location.origin+'/reset-password.html'});if(error&&!/not found/i.test(error.message))return msg(E(error.message));$('#f').hidden=true;msg('If an account exists for that email, a password reset link is on its way.','ok')})},
 reset(){const f=$('#f');sb.auth.onAuthStateChange(ev=>{if(ev==='PASSWORD_RECOVERY'){f.hidden=false;msg('')}});sb.auth.getSession().then(({data:{session}})=>{if(session&&hadLink){f.hidden=false;msg('')}});msg(linkErr()||'Open this page from the reset link in your email. Links expire, so request a new one if needed.',linkErr()?'err':'ok');
  bind([['password',R.password],['confirm',R.match]],async()=>{const{error}=await sb.auth.updateUser({password:$('#password').value});if(error)return msg(E(error.message));f.hidden=true;msg('Password updated. Redirecting…','ok');setTimeout(()=>nav('/dashboard.html'),1500)})},
 async dashboard(){const{data:{user},error}=await sb.auth.getUser();if(error||!user)return nav('/login.html?next=/dashboard.html');
  if(!window._dl){window._dl=1;sb.auth.onAuthStateChange(ev=>{if(ev==='SIGNED_OUT')nav('/login.html')});window.addEventListener('pageshow',e=>{if(e.persisted)location.reload()})}
  const[pr,hi,sv]=await Promise.all([sb.from('profiles').select('full_name').eq('id',user.id).maybeSingle(),sb.from('tool_history').select('tool_slug,used_at').order('used_at',{ascending:false}).limit(40),sb.from('saved_tools').select('tool_slug,created_at').order('created_at',{ascending:false})]);
  if(pr.error&&hi.error&&sv.error)msg('Database tables not found. Run supabase/schema.sql in your Supabase SQL Editor.');
  const name=(pr.data&&pr.data.full_name)||(user.user_metadata||{}).full_name||user.email.split('@')[0],seen=new Set(),rec=[];
  for(const r of hi.data||[])if(!seen.has(r.tool_slug)&&T[r.tool_slug]&&rec.length<8){seen.add(r.tool_slug);rec.push(r)}
  const li=(s,x)=>`<li><a href="${s}.html">${T[s][1]} ${esc(T[s][0])}</a>${x}</li>`,d=x=>new Date(x).toLocaleString(),sl=(sv.data||[]).filter(r=>T[r.tool_slug]);
  $('#dash').innerHTML=`<div class="dg"><section class="pcard" aria-labelledby="h-p"><div class="av" aria-hidden="true">${esc(name[0].toUpperCase())}</div><h2 id="h-p">${esc(name)}</h2><p>${esc(user.email)} <span class="bdg">${user.email_confirmed_at?'Verified':'Not verified'}</span></p>
   <form id="nf" novalidate><label for="nm">Display name</label><input id="nm" value="${esc(name)}" maxlength="60" autocomplete="name"><div class="fe" id="nm-e" role="alert"></div><button class="btn">Save name</button></form></section>
   <section class="pcard"><h2>Account information</h2><ul class="ul"><li>Email<span>${esc(user.email)}</span></li><li>Sign-in method<span>${esc((user.app_metadata||{}).provider||'email')}</span></li><li>Joined<span>${d(user.created_at)}</span></li><li>Last sign-in<span>${d(user.last_sign_in_at)}</span></li></ul><p><button class="btn" id="lo">Log out</button></p></section>
   <section class="pcard"><h2>Recently used tools</h2>${rec.length?`<ul class="ul">${rec.map(r=>li(r.tool_slug,`<small>${d(r.used_at)}</small>`)).join('')}</ul><p><button class="ic" id="ch">Clear history</button></p>`:'<p>No history yet. <a href="all-tools.html">Try a tool</a> while signed in.</p>'}</section>
   <section class="pcard"><h2>Saved tools</h2>${sl.length?`<ul class="ul">${sl.map(r=>li(r.tool_slug,`<button data-s="${esc(r.tool_slug)}" aria-label="Remove ${esc(T[r.tool_slug][0])}">Remove</button>`)).join('')}</ul>`:'<p>Open any tool and press “Save” to keep it here.</p>'}</section></div>`;
  $('#lo').onclick=async()=>{await sb.auth.signOut();nav('/index.html')};
  $('#nf').onsubmit=async e=>{e.preventDefault();const n=$('#nm').value.trim();if(!R.name(n)||R.name(n)!==true){$('#nm-e').textContent='Enter 2–60 characters.';return}$('#nm-e').textContent='';
   const[a,b]=await Promise.all([sb.from('profiles').upsert({id:user.id,full_name:n}),sb.auth.updateUser({data:{full_name:n}})]);msg(a.error||b.error?'Could not save your name.':'Name saved.',a.error||b.error?'err':'ok')};
  const ch=$('#ch');if(ch)ch.onclick=async()=>{await sb.from('tool_history').delete().eq('user_id',user.id);pages.dashboard()};
  document.querySelectorAll('[data-s]').forEach(b=>b.onclick=async()=>{await sb.from('saved_tools').delete().eq('tool_slug',b.dataset.s).eq('user_id',user.id);pages.dashboard()})},
 async tool(){const t=$('#tool');if(!t)return;const{data:{user}}=await sb.auth.getUser();if(!user)return;const slug=t.dataset.tool;let used=0;
  t.addEventListener('input',rec,{once:true});t.addEventListener('click',rec,{once:true});async function rec(){if(used++)return;await sb.from('tool_history').insert({user_id:user.id,tool_slug:slug})}
  const b=document.createElement('button');b.className='ic';b.type='button';t.after(b);let on=false;const draw=()=>{b.textContent=on?'★ Saved to your dashboard':'☆ Save this tool'};
  const{data}=await sb.from('saved_tools').select('tool_slug').eq('tool_slug',slug).maybeSingle();on=!!data;draw();
  b.onclick=async()=>{const{error}=on?await sb.from('saved_tools').delete().eq('tool_slug',slug).eq('user_id',user.id):await sb.from('saved_tools').insert({user_id:user.id,tool_slug:slug});if(!error){on=!on;draw()}}}
};
if(C.key&&unsafe(C.key)){if(P!=='tool'){msg('Security error: a secret/service_role key was found in config.js. Remove it now, use only the publishable key, and rotate the exposed key in Supabase.');document.querySelectorAll('#go,#google').forEach(b=>b.disabled=true)}return}
if(!window.supabase||!C.url||!C.key){if(P!=='tool'){msg('Sign-in is not configured yet: the site owner must set SUPABASE_URL and SUPABASE_ANON_KEY and rebuild.');document.querySelectorAll('#go,#google').forEach(b=>b.disabled=true)}return}
mk();Promise.resolve().then(()=>(pages[P]||(()=>{}))()).catch(()=>msg('Something went wrong. Please refresh and try again.'));
})();
